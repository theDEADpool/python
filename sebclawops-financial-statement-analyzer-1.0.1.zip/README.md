# financial-statement-analyzer

Financial statement analysis skill for OpenClaw.

## Purpose

Use this skill to analyze P&L statements, balance sheets, and similar financial reports for small businesses.

It is designed to be generally useful across businesses, with optional Sea Cool-specific benchmarks as reference points, not hard rules.

## What it covers

- P&L structure
- balance sheet structure
- core financial ratios
- trend comparisons
- QuickBooks-style report interpretation
- anomaly spotting
- structured output for summaries and dashboards

## Best fit

This skill is especially useful for:
- QuickBooks-generated reports
- owner-operator businesses
- service, light manufacturing, and trade businesses
- monthly performance reviews
- dashboard mapping and KPI extraction

## What it is not

- not tax or legal advice
- not a replacement for a CPA
- not a bookkeeping cleanup tool
- not a perfect fraud-detection system

## Recommended output

Keep results practical:
- summary first
- key ratios
- trend notes
- anomalies or questions
- next actions if needed

## Sea Cool notes

Sea Cool examples and margin ranges may be used as internal reference points when relevant, but they should not be treated as universal industry rules.

## Current status

Keep this skill lean and reusable. Business-specific heuristics belong in a small reference section, not the main body.
