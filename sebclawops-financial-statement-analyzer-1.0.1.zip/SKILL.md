---
name: financial-statement-analyzer
description: Analyze P&L statements, balance sheets, and small-business financial documents. Use for QuickBooks-style reports, ratio analysis, trend comparisons, anomaly checks, and dashboard mapping. General by default, with optional Sea Cool benchmarks as reference only.
---

# Financial Statement Analyzer

Use this skill when the user asks to analyze financial statements, compare performance periods, extract KPI data, or review small-business financial documents.

## Scope

Best fit:
- P&L statements
- balance sheets
- QuickBooks reports
- monthly or quarterly comparisons
- KPI extraction for dashboards or spreadsheets

Not for:
- legal advice
- formal tax advice
- audit opinions
- pretending incomplete books are clean

## Core concepts

### P&L
A P&L shows performance over a period.

Use these core lines:
- revenue / total income
- cost of goods sold
- gross profit
- operating expenses
- other income or expense
- net income

Important: net income is not the same as cash.

### Balance sheet
A balance sheet is a point-in-time snapshot.

Use these core sections:
- assets
- liabilities
- equity

Always check whether:
- total assets = total liabilities + equity
- bank balances are being confused with actual free cash
- accounts receivable is being mistaken for cash

### Net cash
Practical shortcut:
- net cash = bank and checking balances minus credit card balances

Use this as an operating reality check, not a formal accounting line.

## Core ratios

Calculate when the data supports it:

- **Net profit margin** = net income / revenue
- **Gross margin** = gross profit / revenue
- **Current ratio** = current assets / current liabilities
- **Quick ratio** = (current assets - inventory) / current liabilities

Interpret conservatively. If the report is incomplete or basis is unclear, say so.

## Trend checks

When prior periods are available:
- compare revenue
- compare gross profit
- compare net income
- compare net cash if balance sheet data is available

Use MoM or YoY as appropriate.

For seasonal businesses, prefer YoY over MoM when seasonality matters.

## QuickBooks guidance

Common patterns:
- parentheses usually mean negative values
- total lines matter more than overly granular sub-lines for top-level analysis
- undeposited funds may behave like a cash-equivalent holding bucket
- opening balance equity or uncategorized lines should be flagged when material

## Anomaly checks

Flag clearly when you see:
- negative or implausible revenue
- balance sheet that does not balance
- uncategorized or ask-my-accountant balances that matter
- large expense spikes without explanation
- margin compression from rising COGS
- AR growing faster than revenue
- cash deterioration despite accounting profit
- one category dominating expenses in a suspicious way

Do not overstate. Flag issues as review items unless the data is obviously broken.

## Sea Cool reference notes

Use these only when relevant to Sea Cool or closely similar businesses.

Examples:
- typical net margin reference range may be around 5% to 13% in normal periods
- unusual swings may still be legitimate due to seasonality, project timing, or low-expense months
- service-business cash flow timing matters more than simple profit snapshots

These are reference points, not universal rules.

## Workflow

1. Identify the document type and period.
2. Extract the important top-line values.
3. Check whether the statements are internally coherent.
4. Calculate the most useful ratios.
5. Compare to prior periods if available.
6. Flag anomalies or questions.
7. Present a practical summary first.

If the statements look incomplete, messy, or contradictory, say that directly.

## Recommended output shape

```text
Financial Analysis: [Company] - [Period]

SUMMARY
- Revenue:
- Gross Profit:
- Net Income:
- Net Cash:

RATIOS
- Net Profit Margin:
- Gross Margin:
- Current Ratio:
- Quick Ratio:

TRENDS
- Revenue change:
- Net Income change:
- Net Cash change:

FLAGS
- [Any anomalies, uncertainties, or questions]

NEXT STEPS
- [What should be reviewed or verified]
```

## Style rules

- summary first
- practical, not academic
- do not fake certainty
- distinguish accounting profit from cash reality
- treat business-specific heuristics as contextual, not absolute
